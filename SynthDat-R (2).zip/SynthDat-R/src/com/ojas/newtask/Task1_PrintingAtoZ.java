package com.ojas.newtask;

public class Task1_PrintingAtoZ {

	public static void main(String[] args) {

		for (char c = 'a'; c <= 'z'; c++) {
            System.out.print(c + " ");
        }
    }


}
