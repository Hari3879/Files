package com.ojas.synthdata2;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class PhoneNumbersGenerator {

	public static void main(String[] args) {
        generatePhoneNumbers(1000);
    }

    private static void generatePhoneNumbers(int count) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("phone.txt"))) {
            Random random = new Random();
            for (int i = 0; i < count; i++) {
                String phoneNumber = generatePhoneNumber(random);
                writer.println(phoneNumber);
            }
            System.out.println("Phone numbers generated and stored in phone.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String generatePhoneNumber(Random random) {
        StringBuilder sb = new StringBuilder();
        sb.append("9"); // Start with "9" series
        for (int i = 0; i < 9; i++) {
            int digit = random.nextInt(10);
            sb.append(digit);
        }
        return sb.toString();
    }
}
