package com.ojas.synthdata2;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class EmailGenerator {


    public static void main(String[] args) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Input File");
        fileChooser.setFileFilter(new FileNameExtensionFilter("Text Files", "txt"));

        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            String inputFileName = fileChooser.getSelectedFile().getAbsolutePath();
            String outputFileName = "menData.txt";

            try {
                // Read names from the input file
                String[] names = readNamesFromFile(inputFileName);

                // Generate email IDs and add country column
                String[][] emails = generateEmails(names);

                // Save the names, email IDs, and country to a file
                saveNamesAndEmailsToFile(names, emails, outputFileName);

                System.out.println("Names, emails, and country generated and saved successfully.");
            } catch (IOException e) {
                System.out.println("Error occurred while generating names, emails, and country: " + e.getMessage());
            }
        }
    }

    public static String[] readNamesFromFile(String fileName) throws IOException {
        FileReader fileReader = new FileReader(fileName);
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        String line;
        StringBuilder stringBuilder = new StringBuilder();

        while ((line = bufferedReader.readLine()) != null) {
            stringBuilder.append(line);
            stringBuilder.append(System.lineSeparator());
        }

        bufferedReader.close();

        String namesString = stringBuilder.toString().trim();
        String[] names = namesString.split(System.lineSeparator());

        return names;
    }

    public static String[][] generateEmails(String[] names) {
        String[][] emails = new String[names.length][2];

        for (int i = 0; i < names.length; i++) {
            String name = names[i];
            String[] nameParts = name.split(" ");

            String firstName = nameParts[0];
            String lastName = nameParts[nameParts.length - 1];

            char firstInitial = firstName.charAt(0);
            char lastInitial = lastName.charAt(0);

            String email = Character.toLowerCase(firstInitial) + "" + Character.toLowerCase(lastInitial) + "@gmail.com";

            emails[i][0] = email;
            emails[i][1] = "America";
        }

        return emails;
    }

    public static void saveNamesAndEmailsToFile(String[] names, String[][] emails, String fileName) throws IOException {
        FileWriter writer = new FileWriter(fileName);

        // Write column headers
        writer.write("Name,Email,Country" + System.lineSeparator());

        // Write names, email IDs, and country in separate columns
        for (int i = 0; i < names.length; i++) {
            writer.write(names[i] + "," + emails[i][0] + "," + emails[i][1] + System.lineSeparator());
        }

        writer.close();
    }
}
