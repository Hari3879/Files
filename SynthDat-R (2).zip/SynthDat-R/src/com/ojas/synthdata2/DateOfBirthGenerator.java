package com.ojas.synthdata2;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ThreadLocalRandom;

public class DateOfBirthGenerator {
    public static void main(String[] args) {
        LocalDate minDate = LocalDate.now().minusYears(100);
        LocalDate maxDate = LocalDate.now().minusYears(18);
        for (int i = 0; i < 100; i++) {
        LocalDate randomDate = getRandomDateOfBirth(minDate, maxDate);
        String formattedDate = randomDate.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));
        System.out.println("Random Date of Birth: " + formattedDate);
        String date = formattedDate;
        String[] values = date.split("-");
        int day = Integer.parseInt(values[0]);
        int month = Integer.parseInt(values[1]);
        int year = Integer.parseInt(values[2]);
        LocalDate dob = LocalDate.of(year, month, day);  
        LocalDate curDate = LocalDate.now();  
        System.out.println(curDate);
      //calculates the difference betwween two dates  
        Period period = Period.between(dob, curDate);  
        //prints the differnce in years, months, and days  
        System.out.printf("Your age is %d years %d months and %d days."+formattedDate, period.getYears(), period.getMonths(), period.getDays());}

        //int i=Integer.parseInt(formattedDate); 
       
        
    }

    private static LocalDate getRandomDateOfBirth(LocalDate minDate, LocalDate maxDate) {
        long minEpochDay = minDate.toEpochDay();
        long maxEpochDay = maxDate.toEpochDay();
        long randomEpochDay = ThreadLocalRandom.current().nextLong(minEpochDay, maxEpochDay);
        return LocalDate.ofEpochDay(randomEpochDay);
    }
}

