package com.ojas.synthdata2;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Task_25_Analytics {

	public static void main(String[] args) {

		String outputFileName = "SqlScript.t";
		List<String[]> lines = new ArrayList<>();
		List<String> sqlStatements = new ArrayList<>();
		JFileChooser fileChooser = new JFileChooser(".");
		fileChooser.setDialogTitle("Select Input File");
		fileChooser.setFileFilter(new FileNameExtensionFilter("Text Files", "txt"));

		int result = fileChooser.showOpenDialog(null);
		if (result == JFileChooser.APPROVE_OPTION) {
			String filePath = fileChooser.getSelectedFile().getPath();

			try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
				// List<String[]> lines = new ArrayList<>();

				String line;

				while ((line = br.readLine()) != null) {

					String[] lineArray = line.split(",");
					String Ages = lineArray[6];
					System.out.println(Ages);

					String[] age = Ages.split(" ");
					String agecrit = age[0];
					System.out.println(agecrit);

					DefaultCategoryDataset dataset = new DefaultCategoryDataset();
					//dataset.addValue( "Age>90", "Teen Age");
					dataset.addValue(30, "Age>50", "Young Age");
					dataset.addValue(60, "Age<60", "Middle Age");
					dataset.addValue(100, "Age", "Ald Age");
					JFreeChart chart = ChartFactory.createBarChart("Age Defined 3D Bar Chart", "AgeCategory", "Share",
							dataset, PlotOrientation.VERTICAL, false, true, false); // Save the chart to an image file
					File outputFile = new File("barchart.png");

					ChartFrame chartFrame = new ChartFrame("Vertical 3D Bar Chart", chart);
					chartFrame.setVisible(true);
					chartFrame.setSize(560, 350);
				}

			}

			// Printing the lines (for demonstration purposes)
//				for (String[] lineArray : lines) {
//					for (String item : lineArray) {
//						System.out.println(item + " ");
//					}
//					System.out.println();
//				}
			// System.out.println(lines.toString());

			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
