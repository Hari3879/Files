/**
 * 
 */
/**
 * @author ho22078
 *
 */
module PrintAtoZ {
	requires java.desktop;
}