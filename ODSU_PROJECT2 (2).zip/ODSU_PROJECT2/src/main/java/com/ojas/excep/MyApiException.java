package com.ojas.excep;
public class MyApiException extends Exception {
    public MyApiException(String message) {
        super(message);
    }
}
