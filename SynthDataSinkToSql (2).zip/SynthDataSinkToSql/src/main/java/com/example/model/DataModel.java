package com.example.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;

@Entity
public class DataModel {
	@GeneratedValue
	int id;
	String Name;
	String Email;
	String Country;
	String Phone;
	String Email2;
	String Dob;

	public DataModel() {
		
	}
	
	

	public DataModel(int id, String name, String email, String country, String phone, String email2, String dob) {
		super();
		this.id = id;
		Name = name;
		Email = email;
		Country = country;
		Phone = phone;
		Email2 = email2;
		Dob = dob;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		Country = country;
	}

	public String getPhone() {
		return Phone;
	}

	public void setPhone(String phone) {
		Phone = phone;
	}

	public String getEmail2() {
		return Email2;
	}

	public void setEmail2(String email2) {
		Email2 = email2;
	}

	public String getDob() {
		return Dob;
	}

	public void setDob(String dob) {
		Dob = dob;
	}
	
	
	

}
