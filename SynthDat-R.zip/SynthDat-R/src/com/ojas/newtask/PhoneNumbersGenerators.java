package com.ojas.newtask;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class PhoneNumbersGenerators {
    public static void main(String[] args) {
        int numberOfPhoneNumbers = 1000;
        String fileName = "phone.txt";

        try {
            FileWriter fileWriter = new FileWriter(fileName);

            for (int i = 0; i < numberOfPhoneNumbers; i++) {
                String phoneNumber = generatePhoneNumber();
                fileWriter.write(phoneNumber + "\n");
            }

            fileWriter.close();
            System.out.println("Phone numbers generated successfully and stored in " + fileName);
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }
    }

    public static String generatePhoneNumber() {
        Random random = new Random();

        // Generate area code
        int areaCode = random.nextInt(800) + 200; // Random number between 200 and 999

        // Generate prefix
        int prefix = random.nextInt(800) + 200; // Random number between 200 and 999

        // Generate line number
        int lineNumber = random.nextInt(9000) + 1000; // Random number between 1000 and 9999

        // Format phone number
        return String.format("(%03d) %03d-%04d", areaCode, prefix, lineNumber);
    }
}

