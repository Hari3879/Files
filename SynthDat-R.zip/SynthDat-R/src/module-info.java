/**
 *
 */
/**
 * @author ho22078
 *
 */
module PrintAtoZ {
	requires java.desktop;
	requires java.logging;
}