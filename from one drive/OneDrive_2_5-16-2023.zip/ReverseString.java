package com.ojas.test;

class ReverseString {
	private static void swap(char[] chars, int i, int j) {
		char temp = chars[i];
		chars[i] = chars[j];
		chars[j] = temp;
	}

	public static void reverseText(char[] chars, int begin, int end) {
		while (begin < end) {
			swap(chars, begin++, end--);
		}
	}

	public static String reverseText(String str) {
		if (str == null || str.length() == 0) {
			return str;
		}

		char[] chars = str.toCharArray();

		int low = 0, high = 0;

		for (int i = 0; i < chars.length; i++) {
			if (chars[i] == ' ') {
				reverseText(chars, low, high);

				low = high = i + 1;
			} else {
				high = i;
			}
		}

		reverseText(chars, low, high);

		reverseText(chars, 0, chars.length - 1);

		return new String(chars);
	}

	public static void main(String[] args) {
		String str = "Preparation Interview Technical";

		System.out.println(reverseText(str));
	}
}
