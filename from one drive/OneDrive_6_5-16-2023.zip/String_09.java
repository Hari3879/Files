package com.ojas.string;

public class String_09 {

	public static void main(String[] args) {
		String input = "this is the first string .";

		input = input.replaceAll("\\s", "%20");
		System.out.println(input);

	}

}
