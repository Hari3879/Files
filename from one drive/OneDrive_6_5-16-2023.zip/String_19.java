package com.ojas.string;

import java.util.Scanner;

public class String_19 {
	public String stringRotation(String firstString, String secondString) {

		String output = "";
		for (int i = 0; i < firstString.length(); i++) {
			if (i == 0) {
				output += firstString.charAt(firstString.length() - 1);
			} else if (i == firstString.length() - 1) {
				output += firstString.charAt(i - 1);
			} else {
				output += firstString.charAt(i - 1);
			}
		}
		System.out.println(output);
		if (output.equals(secondString)) {
			return "equal";
		} else {
			return "not equal";
		}
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.println("enter first string");
		String firstString = s.next();

		System.out.println("enter second string");
		String secondString = s.next();

		String_19 obj = new String_19();

		System.out.println(obj.stringRotation(firstString, secondString));
	}

}
