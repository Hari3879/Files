package com.ojas.string;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class String_18 {
	public String duplicates(String input) {
		String output = "";
		char[] array = input.toCharArray();

		for (int i = 0; i < array.length; i++) {
			int count = 1;
			for (int j = i + 1; j < array.length; j++) {
				if (array[i] == array[j]) {
					count++;
				}
			}

			if (count > 1) {
				output += array[i];
			}
			array[i] = '\0';
		}
		return output;

	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.println("enter first string");
		String firstString = s.next();

		String_18 obj = new String_18();

		System.out.println(obj.duplicates(firstString));
	}

}
