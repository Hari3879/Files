/*
 * to check whether two strings are anagram or not?
 * 
 * anagram:    silent and listen has same characters in the word .those two are anagram strings
 */

package com.ojas.string;

import java.util.Arrays;
import java.util.Scanner;

public class String_02 {
	public String anagram(String firstString, String secondString) {
		String result1 = "", result2 = "";
		char[] array1 = firstString.toCharArray();
		char[] array2 = secondString.toCharArray();

		Arrays.sort(array1);
		Arrays.sort(array2);

		for (int i = 0; i < array1.length; i++) {
			result1 += array1[i];
			result2 += array2[i];
		}

		if (result1.equals(result2)) {
			return "anagram";
		} else {
			return "not anagram";
		}
	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("enter first string");
		String firstString = s.next();

		System.out.println("enter second string");
		String secondString = s.next();

		String_02 obj = new String_02();

		System.out.println(obj.anagram(firstString, secondString));

	}
}
