package com.ojas.string;

import java.util.Arrays;
import java.util.Scanner;

public class String_15 {
	public String uniqueString(String input) {
		boolean value = false;
		char[] array = input.toCharArray();
		Arrays.sort(array);
		for (int i = 0; i < array.length-1; i++) {
			if (array[i] == array[i + 1]) {
				value = true;
			}
		}
		if (!value) {
			return "unique string";
		} else
			return "not an unique string";
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.println("enter first string");
		String firstString = s.next();

		String_15 obj = new String_15();

		System.out.println(obj.uniqueString(firstString));

	}

}
