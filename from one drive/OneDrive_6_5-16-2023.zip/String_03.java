package com.ojas.string;

import java.util.Scanner;

public class String_03 {

	public String checkPalindrome(String firstString) {
		String result = "";
		for (int i = firstString.length() - 1; i >= 0; i--) {
			result += firstString.charAt(i);
		}
		if (result.equals(firstString)) {
			return "palindrome";
		} else
			return "not pallindrome";

	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.println("enter first string");
		String firstString = s.next();

		String_03 obj = new String_03();

		System.out.println(obj.checkPalindrome(firstString));

	}

}
