package com.ojas.string;

import java.util.Scanner;

public class String_20 {
public String subString(String input){
	return input;
	
}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.println("enter first string");
		String firstString = s.next();

		String_20 obj = new String_20();

	}

}
