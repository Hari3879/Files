package com.ojas.string;

import java.util.Scanner;

public class String_08 {
	public String reversedString(String input) {
		String output = "";

		String[] array = input.split(" ");

		for (int i = 0; i < array.length; i++) {
			for (int j = array[i].length() - 1; j >= 0; j--) {
				output += array[i].charAt(j);
			}
			output += " ";
		}
		return output;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.println("enter first string");
		String firstString = s.nextLine();

		String_08 obj = new String_08();

		System.out.println(obj.reversedString(firstString));

	}

}
