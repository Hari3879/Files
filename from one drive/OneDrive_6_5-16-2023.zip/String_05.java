package com.ojas.string;

import java.util.Scanner;

public class String_05 {
	public String reversedString(String input) {
		String output = "";
		for (int i = input.length() - 1; i >= 0; i--) {
			output += input.charAt(i);
		}
		return output;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.println("enter first string");
		String firstString = s.next();

		String_05 obj = new String_05();

		System.out.println("the reversed string is: " + obj.reversedString(firstString));

	}

}
