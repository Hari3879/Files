package com.ojas.string;

import java.util.Arrays;

public class String_10 {
	public static void main(String[] args) {
		String input="hello";
		
		char[] array=input.toCharArray();
		
		for(int i=0;i<array.length;i++){
			int count=1;
			for(int j=i+1;j<array.length;j++){
				if(array[i]==array[j]){
					count++;
				}
			}
			System.out.println(array[i]+":"+count);
			array[i]='\0';
		}

	}

}
