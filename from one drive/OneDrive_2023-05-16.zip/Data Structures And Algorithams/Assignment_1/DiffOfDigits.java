package Assignment_1;

import java.util.Scanner;

public class DiffOfDigits {

	public static void main(String[] args) {
		int number;
		System.out.println("enter number");
		Scanner s = new Scanner(System.in);
		number = s.nextInt();
		System.out.println(getDiffOfDigits(number));
		
	}
	public  static int getDiffOfDigits(int number){
		
		if(number<0){
			return -3;
		}
		else if(number>99){
			return -2;
		}
		else if(number>=0&&number<=9){
			return -1;
		}
		else{
			int firstDigit=number/10;
			int secondDigit=number%10;
			return firstDigit-secondDigit;
		}
		
		
	}

}
