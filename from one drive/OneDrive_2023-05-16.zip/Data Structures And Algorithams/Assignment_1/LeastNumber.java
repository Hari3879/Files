package Assignment_1;

import java.util.Scanner;

public class LeastNumber {

	public static int isLeast(int firstNumber, int secondNumber) {
		if (firstNumber < 0 || secondNumber < 0) {
			return -1;
		} else if (firstNumber == 0 || secondNumber == 0) {
			return -2;
		} else if (firstNumber < secondNumber) {
			return firstNumber;
		} else
			return secondNumber;
	}

	public static void main(String[] args) {
		int firstNumber, secondNumber;
		System.out.println("enter first number");
		Scanner s = new Scanner(System.in);
		firstNumber = s.nextInt();
		System.out.println("enter second number");
		secondNumber = s.nextInt();
		System.out.println("least number is:" + isLeast(firstNumber, secondNumber));

	}

}
