package Assignment_1;

import java.util.Scanner;

public class CountBoolean {

	public static boolean countBoolean(boolean firstValue,boolean secondValue,boolean thirdValue){
		if((firstValue==true&&secondValue==true&&thirdValue==true)||(firstValue==true&&secondValue==true)||(firstValue==true&&thirdValue==true)||(secondValue==true&&thirdValue==true)){
			return true;
		}
		else
			return false;
	}
	public static void main(String[] args) {
		boolean firstValue,secondValue,thirdValue;
		Scanner s=new Scanner(System.in);
		System.out.println("enter first value");
		firstValue=s.nextBoolean();
		System.out.println("enter second value");
		secondValue=s.nextBoolean();
		System.out.println("enter third value");
		thirdValue=s.nextBoolean();
		System.out.println(countBoolean(firstValue,secondValue,thirdValue));

	}

}
