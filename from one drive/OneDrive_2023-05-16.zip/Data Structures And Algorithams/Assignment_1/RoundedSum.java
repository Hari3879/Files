package Assignment_1;

import java.util.Scanner;

public class RoundedSum {

	public static int sumOfMultiples(int firstNumber,int secondNumber,int thirdNumber){
		int sum=0;
		if(firstNumber%10==0){
			sum+=firstNumber;
		}
		else{
			sum+=((firstNumber/10)+1)*10;
		}
		if(secondNumber%10==0){
			sum+=secondNumber;
		}
		else{
			sum+=((secondNumber/10)+1)*10;
		}
		if(thirdNumber%10==0){
			sum+=thirdNumber;
		}
		else{
			sum+=((thirdNumber/10)+1)*10;
		}
		return sum;
	}
	public static void main(String[] args) {
		int firstNumber,secondNumber,thirdNumber;
		Scanner s=new Scanner(System.in);
		System.out.println("enter first number");
		firstNumber=s.nextInt();
		System.out.println("enter second number");
		secondNumber=s.nextInt();
		System.out.println("enter third number");
		thirdNumber=s.nextInt();
		
		System.out.println(sumOfMultiples(firstNumber,secondNumber,thirdNumber));

	}

}
