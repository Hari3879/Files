package Assignment_1;

import java.util.Scanner;

public class Palindrome {

	public static int isPalindrome(int number){
		
		int reminder,sum=0,quotient;
		int temp=number;
		while(number!=0){
			reminder=number%10;
			sum=sum*10+reminder;
			number=number/10;
			
		}
		if(sum==temp){
			return 1;
		}else
			return 0;
	}
	public static void main(String[] args) {
		
		int number;
		System.out.println("enter number");
		Scanner s = new Scanner(System.in);
		number = s.nextInt();
		
		System.out.println(isPalindrome(number));

	}

}
