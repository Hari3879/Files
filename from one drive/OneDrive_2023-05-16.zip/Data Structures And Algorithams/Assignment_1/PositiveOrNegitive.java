package Assignment_1;

import java.util.Scanner;

public class PositiveOrNegitive {

	public static int isSign(int number) {
		if (number > 0) {
			return 1;
		} else if (number < 0) {
			return -1;
		} else
			return 0;
	}

	public static void main(String[] args) {

		int number;
		System.out.println("enter number");
		Scanner s = new Scanner(System.in);
		number = s.nextInt();
		System.out.println(isSign(number));
	}

}
