package Assignment_1;

import java.util.Scanner;

public class EvenOrOdd {

	public static String isEvenOrOdd(int number){
		if(number<=0){
			return "invalid input";
		}
		else{
			if(number%2==0){
				return "even number";
			}
			else
				return "odd number";
		}
	}
	public static void main(String[] args) {
		int number;
		System.out.println("enter number");
		Scanner s = new Scanner(System.in);
		number = s.nextInt();
		
		System.out.println(isEvenOrOdd(number));


	}

}
