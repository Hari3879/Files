package Assignment_1;

import java.util.Scanner;

public class Calculate {

	public static int calculate(int number){
		if(number<=0){
			return -1;
		}
	    else if(number%2==0){
			return number*number;
		}
		else
			return number*number*number;
			
	}

	public static void main(String[] args) {
		int number;
		System.out.println("enter number");
		Scanner s = new Scanner(System.in);
		number = s.nextInt();
		
		System.out.println(calculate(number));

	}

}
