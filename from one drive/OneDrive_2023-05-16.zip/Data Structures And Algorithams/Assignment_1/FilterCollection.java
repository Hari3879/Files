package Assignment_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

 class Product {
	public int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String name;
	public float price;
	public Product(int id, String name, float price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
		 public String toString() {
			 return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";}

}
public class FilterCollection {
	
	public static void main(String[] args) {
		List<Product> li = new ArrayList<Product>();
		li.add(new Product(1,"Nani",100));
		li.add(new Product(8,"Merugu",200));
		li.add(new Product(3,"CHintu",300));
		li.add(new Product(4,"Mammu",400));
//		Stream <Product> filteredata = li.stream().filter(p->p.price>200);
//		filteredata.forEach(product->System.out.println(product.name+":"+product.price));
		List<Product> filteredata =li.stream().sorted(Comparator.comparing(Product::getId)).collect(Collectors.toList());
		for(Product e:filteredata){
			System.out.println(e.getId());
		}
	}
}
