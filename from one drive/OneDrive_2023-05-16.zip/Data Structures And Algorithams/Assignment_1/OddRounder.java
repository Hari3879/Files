package Assignment_1;

import java.util.Scanner;

public class OddRounder {
public static int oddRounder(int number){
	if(number%2==0){
		return number;
	}
	else{
		int result=number/10;
	return (result+1)*10;}
}
	public static void main(String[] args) {
		int number;
		System.out.println("enter number");
		Scanner s = new Scanner(System.in);
		number = s.nextInt();
		
		System.out.println(oddRounder(number));


	}

}
