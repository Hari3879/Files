package Assignment_1;

import java.util.Scanner;

public class nextMultipleOf100 {
	
	public static int getNextMultipleOf100(int number){
		if(number<=0){
			return -1;
		}else{
		int result=number/100;
		return (result+1)*100;}
	}
	public static void main(String[] args) {
		
		int number;
		System.out.println("enter number");
		Scanner s=new Scanner(System.in);
		number=s.nextInt();
		
		
		System.out.println("the next multiple of given number is:"+getNextMultipleOf100(number));
	}

	

}
