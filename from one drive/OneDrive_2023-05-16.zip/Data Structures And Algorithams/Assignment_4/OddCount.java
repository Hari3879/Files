package Assignment_4;

public class OddCount {
	public String getOddCount(int[] array) {
		String result = "";
		int count = 0;
		if (array.length != 5) {
			result = "-1";
		} else if (array.length == 0) {
			result = "-4";

		} else {
			for (int i = 0; i < array.length; i++) {
				if (array[i] <= 0) {
					result = "-2";
				} else if (array[i] % 2 == 0) {
					count++;
				} else {
					result += array[i];
				}
			}
			if (count == array.length) {
				result = "-3";
			}
		}
		return result;

	}

	public static void main(String[] args) {
		OddCount oc = new OddCount();

		int[] array = { 2, 4, 5 };
		System.out.println(oc.getOddCount(array));
	}

}
