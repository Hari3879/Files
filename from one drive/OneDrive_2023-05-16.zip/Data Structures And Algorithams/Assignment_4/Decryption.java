package Assignment_4;

import java.util.Scanner;

public class Decryption {
	String str = "abcdefghijklmnopqrstuvwxyz";
	String reverseString = "";

	public String decrypt(String input) {
		String result = "";
		char[] array = input.toCharArray();
		for (int i = 0; i < array.length; i++) {
			if (array[i] < 'a' && array[i] > 'z') {
				result = null;
			}
		}
		int startIndex = reverseString.indexOf(input.charAt(0));
		int endIndex = startIndex + input.length();
		for (int i = startIndex; i < endIndex; i++) {
			result += str.charAt(i);
		}

		return result;

	}

	public static void main(String[] args) {
		Decryption d = new Decryption();

		for (int i = d.str.length() - 1; i >= 0; i--) {
			d.reverseString += d.str.charAt(i);
		}
		Scanner s = new Scanner(System.in);
		System.out.println("enter input");
		String input = s.next();

		System.out.println("output is: "+d.decrypt(input));

	}

}
