package Assignment_4;

import java.util.Scanner;

public class IncrDecr {
	public static int[] getIncreaseDecrease(int number) {

		int[] result = new int[number];
		int initialInput = 1;
		for (int i = 0; i < result.length; i++) {
			if (i % 2 == 0) {
				result[i] = initialInput;
				initialInput++;
			} else {
				result[i] = number;
				number--;
			}
		}
		return result;
	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("enter input");
		int number = s.nextInt();
		int array[] = getIncreaseDecrease(number);
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}

	}

}
