package Assignment_4;

import java.util.Scanner;

public class Encryption {
	String str = "abcdefghijklmnopqrstuvwxyz";
	String reverseString = "";

	public String encrypt(String input) {
		String result = "";
		char[] array = input.toCharArray();
		for (int i = 0; i < array.length; i++) {
			if (array[i] < 'a' && array[i] > 'z') {
				result = null;
			}
		}
		int startIndex = str.indexOf(input.charAt(0));
		int endIndex = startIndex + input.length();
		for (int i = startIndex; i < endIndex; i++) {
			result += reverseString.charAt(i);
		}

		return result;

	}

	public static void main(String[] args) {

		Encryption e = new Encryption();

		for (int i = e.str.length() - 1; i >= 0; i--) {
			e.reverseString += e.str.charAt(i);
		}
		Scanner s = new Scanner(System.in);
		System.out.println("enter input");
		String input = s.next();

		System.out.println("output is: "+e.encrypt(input));

	}

}
