package Assignment_4;

import java.util.Scanner;

public class MajorMinor {
	public boolean isMajor(int gender, int age) {
		boolean value;

		if ((gender == 1 && age >= 21) || (gender == 2 && age >= 18)) {
			value = true;
		} else
			value = false;
		return value;

	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("enter gender?");
		String gen = s.next();
		int gender;
		if (gen.equals("male")) {
			gender = 1;
		} else
			gender = 2;

		System.out.println("enter age?");
		int age = s.nextInt();

		MajorMinor mm = new MajorMinor();
		System.out.println("is major? "+mm.isMajor(gender, age));

	}

}
