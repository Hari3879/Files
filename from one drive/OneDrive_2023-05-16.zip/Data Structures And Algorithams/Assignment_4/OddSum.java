package Assignment_4;

public class OddSum {
public int getOddSum(int[] array){
	int result = 0;
	int count = 0;
	if (array.length >0&&array.length!=5) {
		result = -1;
	} else if (array.length == 0) {
		result = -4;

	} else {
		for (int i = 0; i < array.length; i++) {
			if (array[i] <= 0) {
				result = -2;
			} else if (array[i] % 2 == 0) {
				count++;
			} else {
				result += array[i];
			}
		}
		if (count == array.length) {
			result = -3;
		}
	}
	return result;
}
	public static void main(String[] args) {
		OddSum os=new OddSum();
		
		int []array={ 2,4,4,5,7};
		System.out.println(os.getOddSum(array));

	}

}
