package Assignment_4;

import java.util.Scanner;

public class ArrayColumnSum {
public int[] getColumnSum(int array[][]){
	
	int result[] = new int[3];
	 int cols = array[0].length; 
	for (int j = 0; j < array.length; j++) {
		for (int i = 0; i < array.length;i ++) {
			result[i] += array[j][i];
		}
	}

	return result;


	
}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		int[][] array = new int[][] { { 4, 2, 6 }, { 3, 4, 5 }, { 4, 5, 6 } };

		ArrayColumnSum ars = new ArrayColumnSum();
		int[] output = ars.getColumnSum(array);
		for (int i = 0; i < output.length; i++) {
			System.out.println("sum of " + i + " column is " + output[i]);
		}

	}

}
