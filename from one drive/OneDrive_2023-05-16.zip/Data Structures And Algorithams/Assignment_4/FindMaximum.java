package Assignment_4;

public class FindMaximum {
	public static int findMax(int[] array) {
		int result, count = 0;
		if (array.length == 0) {
			result = 0;
		} else {
			for (int i = 0; i < array.length; i++) {
				if (array[i] <= 0) {
					count++;
				}
			}
			if (count < 3) {
				result = -1;
			} else {

				result = array[0];
				for (int i = 0; i < array.length; i++) {
					if (array[i] > result) {
						result = array[i];
					}
				}
			}
		}

		return result;

	}

	public static void main(String[] args) {
		int[] array = { 1, -2, -3, -2, -3, 10 };
		System.out.println("maximun number in the given array is:  " + findMax(array));

	}

}
