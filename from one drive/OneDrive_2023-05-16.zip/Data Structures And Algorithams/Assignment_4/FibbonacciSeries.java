package Assignment_4;

import java.util.Scanner;

public class FibbonacciSeries {
	public String getFibonacciSeries(int number) {

		int number1 = 0, number2 = 1, number3;
		String result = number1 + " " + number2 + " ";
		for (int i = 2; i <= number; i++) {
			number3 = number1 + number2;
			result += number3 + " ";
			number1 = number2;
			number2 = number3;
		}
		return result;

	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("enter number");
		int number = s.nextInt();

		FibbonacciSeries fs = new FibbonacciSeries();
		System.out.println(fs.getFibonacciSeries(number));

	}

}
