package Assignment_4;

import java.util.Scanner;

public class CricketScores {
public String getDisplayDetails(int runs, float overs){
	String result="";
	int balls=(int) ((int)overs*6+((overs-(int)overs)*10));
	if(balls<100||runs<100){
		result+=runs+"runs in"+balls+"balls @"+(runs/balls)+"runs per ball";
	}
	else
		result+=runs+"runs in"+overs+"overs @"+(((float)runs/balls)*6)+"runs per over";
	return result;
	
}
	public static void main(String[] args) {
		CricketScores cs=new CricketScores();
		
		Scanner s=new Scanner(System.in);
		System.out.println("enter runs");
		int runs=s.nextInt();
		
		System.out.println("enter overs");
		float overs=s.nextFloat();
		
		System.out.println(cs.getDisplayDetails(runs, overs));

	}

}
