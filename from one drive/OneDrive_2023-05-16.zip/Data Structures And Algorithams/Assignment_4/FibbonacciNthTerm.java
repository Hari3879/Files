package Assignment_4;

import java.util.Scanner;

public class FibbonacciNthTerm {
	public int getNthTermOfFibonacciSeries(int number) {

		int number1 = 0, number2 = 1, number3 = 0, count = 2;
		while (count < number) {
			for (int i = 2; i <= number; i++) {
				number3 = number1 + number2;
				number1 = number2;
				number2 = number3;
				count++;
			}
		}
		return number1;

	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("enter input");
		int number = s.nextInt();

		FibbonacciNthTerm ft = new FibbonacciNthTerm();
		System.out.println(ft.getNthTermOfFibonacciSeries(number));

	}

}
