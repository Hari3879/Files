package Assignment_4;

import java.util.Scanner;

public class NameScore {
	String str = "abcdefghijklmnopqrstuvwxyz";
public int getNameScore(String name){
	String input=name.toLowerCase();
	int result=0;
	for(int i=0;i<input.length();i++){
		result+=(str.indexOf(input.charAt(i))+1);
	}
	return result;
	
}
	public static void main(String[] args) {
		NameScore ns=new NameScore();
		
		Scanner s=new Scanner(System.in);
		System.out.println("enter input string");
		String input=s.next();

		System.out.println(ns.getNameScore(input));
	}

}
