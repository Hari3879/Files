package Assignment_4;

import java.util.Scanner;

public class ArrayRowSum {
	public int[] getRowSum(int array[][]) {
		int result[] = new int[3];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				result[i] += array[i][j];
			}
		}

		return result;

	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		int[][] array = new int[][] { { 4, 2, 3 }, { 3, 4, 5 }, { 4, 5, 6 } };

		ArrayRowSum ars = new ArrayRowSum();
		int[] output = ars.getRowSum(array);
		for (int i = 0; i < output.length; i++) {
			System.out.println("sum of " + i + " row is " + output[i]);
		}

	}

}
