package Assignment_2;

import java.util.Scanner;

public class StringWeaver {
public String getWeavedString(String firstString,String secondString){
	
	if(firstString==""||secondString==""){
		return "-1";
	}
	else if(firstString.length()>secondString.length()){
		return secondString+firstString+secondString;
	}
	else if(firstString.length()<secondString.length()){
		return firstString+secondString+firstString;
	}
	else{
		String result="";
		for(int i=0;i<firstString.length();i++){
			result+=firstString.charAt(i)+""+secondString.charAt(i);
		}
		return result;
	}
}
	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		
		System.out.println("enter first string");
		String firstString=s.next();
		
		System.out.println("enter second string");
        String secondString=s.next();
        
        StringWeaver sw=new StringWeaver();
        System.out.println(sw.getWeavedString(firstString,secondString));
		
	}

}
