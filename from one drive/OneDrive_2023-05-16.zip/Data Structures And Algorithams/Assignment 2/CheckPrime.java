package Assignment_2;

import java.util.Scanner;

public class CheckPrime {

	public String checkPrime(int number) {
		if (number < 0) {
			return "-1";
		} else if (number == 0 || number == 1) {
			return "-2";
		} else {
			int count = 0;
			for (int i = 1; i <= number; i++) {
				if (number % i == 0) {
					count++;
				}
			}
			if (count <= 2) {
				return "true";
			} else
				return "false";

		}
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("enter number");
		int number = s.nextInt();

		CheckPrime cp = new CheckPrime();

		System.out.println(cp.checkPrime(number));

	}

}
