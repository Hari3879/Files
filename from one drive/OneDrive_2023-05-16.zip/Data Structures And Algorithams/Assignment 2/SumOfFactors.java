package Assignment_2;

import java.util.Scanner;

public class SumOfFactors {
	public int getSumOfFactors(int number){
		int sum=0;
		if(number<0){
			return -1;
		}
		else if(number==0){
			return -2;
		}
		else{
			for(int i=1;i<=number;i++){
				if(number%i==0){
					sum+=i;
				}
			}
			return sum;
		}
	}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter number");
		int number=s.nextInt();
		
		SumOfFactors sf=new SumOfFactors();
		System.out.println("factors are:"+sf.getSumOfFactors(number));

	}

}
