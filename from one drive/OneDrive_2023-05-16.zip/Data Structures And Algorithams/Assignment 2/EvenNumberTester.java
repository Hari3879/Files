package Assignment_2;

import java.util.Scanner;

public class EvenNumberTester {
	public String getEvenNumbers(int firstNumber, int secondNumber) {
		String result = "";
		if (firstNumber < 0 && secondNumber < 0) {
			return "-1";
		} else if (firstNumber == 0 || firstNumber == secondNumber) {
			return "-2";
		} else {
			if (firstNumber < secondNumber) {
				for (int i = firstNumber; i <= secondNumber; i++) {
					if (i % 2 == 0) {
						result += i + " ";
					}
				}
			} else {
				for (int i = secondNumber; i <= firstNumber; i++) {
					if (i % 2 == 0) {
						result += i + " ";
					}
				}
			}
			return result;
		}
	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("enter first number");
		int firstNumber = s.nextInt();

		System.out.println("enter second number");
		int secondNumber = s.nextInt();

		EvenNumberTester et = new EvenNumberTester();
		System.out.println("factors are:" + et.getEvenNumbers(firstNumber, secondNumber));
	}

}
