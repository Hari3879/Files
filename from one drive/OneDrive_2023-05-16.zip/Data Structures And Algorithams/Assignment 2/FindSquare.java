package Assignment_2;

import java.util.Scanner;

public class FindSquare {
public int getSquare(int number){
	if(number<0){
		return -2;
	}
	else if(number==0){
		return -1;
	}
	else
		return number*number;
}
	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("enter number");
		int number=s.nextInt();
		
		FindSquare fs=new FindSquare();
		System.out.println("the square of the number is:"+fs.getSquare(number));

	}

}
