package Assignment_2;

public class NumberPattern4 {
	public String numberPattern4(int number){
		String value="";
		for(int i=1;i<=number;i++){
			for(int j=1;j<=i;j++){
				value+=(j*i)+" ";
				
			}
			value+="\n";
		}
		return value;
	}
	public static void main(String[] args) {
		NumberPattern4 np=new NumberPattern4();
		System.out.println(np.numberPattern4(5));

	}

}
