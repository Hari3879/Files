package Assignment_2;

import java.util.Scanner;

public class CheckArmstrong {
public static String checkArmstrong(int number){
		if(number<0){
			return "-1";
		}
		else if(number<1000){
			return "-2";
		}
		else{
			
		int remainder,sum=0;
		int temp=number;
		while(number!=0){
			 remainder = number % 10;
	            sum += Math.pow(remainder, 4);
	            number /= 10;
		}
		if(sum==temp){
			return "ArmStrong Number";
		}else
			return "Not ArmStrong Number";
	}
}
	public static void main(String[] args) {
		int number;
		System.out.println("enter number");
		Scanner s = new Scanner(System.in);
		number = s.nextInt();
	
		System.out.println(checkArmstrong(number));

	}

}
