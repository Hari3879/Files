package Assignment_2;

public class Box {
public String createBoxPattern(int rows,int columns){
	String value = "";
	if(rows>0&&columns>0){
		for(int i=1;i<=rows;i++){
			for(int j=1;j<=columns;j++){
				if((i==1)||(i==rows)||(j==1)||(j==columns)){
					value+= "*";
				}
				else{
					 value+=" ";
				}
			}
			value+="\n";
		}
		return value;
	}
	else if(rows<0&&columns<0){
		return "-1";
	}
	else{	
		return "-2";
	}
}
	public static void main(String[] args) {
		Box b=new Box();
		System.out.println(b.createBoxPattern(4,5));

	}

}
