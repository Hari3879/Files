package Assignment_2;

import java.util.Scanner;

public class ListPrimes {
public String getPrimeNumbers(int firstNumber,int secondNumber){
	if(firstNumber<0&&secondNumber<0){
		return "-1";
	}
	else if(firstNumber>secondNumber){
		return "-2";
	}
	else{
		String result="";
		for(int i=firstNumber;i<=secondNumber;i++){
			int count=0;
			for(int j=1;j<=i;j++){
				if(i%j==0){
					count++;
				}
			}
			if(count<=2){
			   result+=i+" ";
			}
		}
		return result;
	}
}
	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		
		System.out.println("enter first number");
		int firstNumber=s.nextInt();
		
		System.out.println("enter second number");
		int secondNumber=s.nextInt();
		
		ListPrimes lp=new ListPrimes();
		System.out.println(lp.getPrimeNumbers(firstNumber, secondNumber));

	}

}
