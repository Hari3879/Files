package Assignment_2;

import java.util.Scanner;

public class Factorial {
	public int getFactorial(int number) {
		if (number < 0) {
			return -1;
		} else if (number == 0) {
			return -2;
		} else {
			int fact = 1;
			for (int i = 1; i <= number; i++) {
				fact = fact * i;
			}
			return fact;
		}
	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("enter number");
		int number = s.nextInt();
		Factorial f = new Factorial();
		System.out.println("the factorial of the number is:"+f.getFactorial(number));

	}

}
