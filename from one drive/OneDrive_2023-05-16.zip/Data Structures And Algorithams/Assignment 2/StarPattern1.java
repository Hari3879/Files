package Assignment_2;

public class StarPattern1 {

	public String createStarPattern(int number){
		String value="";
		for(int i=1;i<=number;i++){
			for(int j=1;j<=i;j++){
				value+="*";
			}
			value+="\n";
		}
		return value;
	}
	public static void main(String[] args) {
		StarPattern1 sp=new StarPattern1();
		System.out.println(sp.createStarPattern(4));

	}

}
