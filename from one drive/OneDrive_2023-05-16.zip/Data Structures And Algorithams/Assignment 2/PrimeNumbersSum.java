package Assignment_2;

import java.util.Scanner;

public class PrimeNumbersSum {
	public int PrimeNumbersSum(int firstNumber, int secondNumber) {

		if(firstNumber<0&&secondNumber<0){
			return -1;
		}
		else if(firstNumber==0||secondNumber==0){
			return -2;
		}
		else if(firstNumber>secondNumber){
			return -3;
		}
		else
		{
			int sum=0;
			for(int i=firstNumber;i<=secondNumber;i++){
				int count=0;
				for(int j=1;j<=i;j++){
					if(i%j==0){
						count++;
					}
				}
				if(count<=2){
				   sum+=i;
				}
			}
			return sum;
		}
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.println("enter first number");
		int firstNumber = s.nextInt();

		System.out.println("enter second number");
		int secondNumber = s.nextInt();

		PrimeNumbersSum ps = new PrimeNumbersSum();
		System.out.println("sum of the prime numbers in the given range: "+ps.PrimeNumbersSum(firstNumber, secondNumber));

	}

}
