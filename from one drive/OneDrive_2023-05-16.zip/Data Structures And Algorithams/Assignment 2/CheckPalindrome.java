package Assignment_2;

import java.util.Scanner;

public class CheckPalindrome {
	public static String checkPalindrome(int number) {
		if (number < 0) {
			return "-1";
		} else if (number >= 0 && number <= 9) {
			return "-2";
		} else {
			int reminder, sum = 0;
			int temp = number;
			while (number != 0) {
				reminder = number % 10;
				sum = sum * 10 + reminder;
				number = number / 10;

			}
			if (sum == temp) {
				return "true";
			} else
				return "false";
		}
	}

	public static void main(String[] args) {
		int number;
		System.out.println("enter number");
		Scanner s = new Scanner(System.in);
		number = s.nextInt();

		System.out.println(checkPalindrome(number));

	}

}
