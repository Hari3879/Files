package Assignment_2;

import java.util.Scanner;

public class FindTriangle {
public String findTriangle(int firstValue,int secondValue,int thirdValue){
	
	if(firstValue==0&&secondValue==0&&thirdValue==0){
		return "-1";
	}
	else if(firstValue<0&&secondValue<0&&thirdValue<0){
		return "-2";
	}
	else{
		if(firstValue==secondValue&&secondValue==thirdValue){
			return "Equilateral triangle";
		}
		else if((firstValue==secondValue)||(firstValue==thirdValue)||(secondValue==thirdValue)){
			return "isosceles triangle";
		}
		else
			return "scalene triangle";
	}
	
}
	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("enter first value");
		int firstValue=s.nextInt();
		
		System.out.println("enter second value");
		int secondValue=s.nextInt();
		
		System.out.println("enter third value");
		int thirdValue=s.nextInt();
		
		FindTriangle ft=new FindTriangle();
		System.out.println(ft.findTriangle(firstValue,secondValue,thirdValue));

	}

}
