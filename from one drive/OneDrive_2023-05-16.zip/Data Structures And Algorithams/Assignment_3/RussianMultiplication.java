package Assignment_3;

import java.util.Scanner;

public class RussianMultiplication {
	public static int getProduct(int num1, int num2) {

		if (num1 < 0 || num2 < 0) {
			return -1;
		} else {
			int product = 0;

			while (num2 > 0) {

				if (num2 % 2 != 0) {
					product = product + num1;
				}

				num1 *= 2;
				num2 /= 2;
			}
			return product;
		}

	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("enter first number");
		int firstNumber = s.nextInt();

		System.out.println("enter second number");
		int secondNumber = s.nextInt();

		System.out.println(getProduct(firstNumber, secondNumber));

	}

}
