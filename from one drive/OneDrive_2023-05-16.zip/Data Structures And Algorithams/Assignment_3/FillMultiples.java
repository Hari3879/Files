package Assignment_3;

import java.util.Scanner;

public class FillMultiples {
	public static int[] getMultiplesArray(int number) {
		if (number <= 0) {
			return null;
		} else {
			int result[] = new int[10];
			for (int i = 0; i < 10; i++) {
				result[i] = number * (i + 1);
			}
			return result;
		}
	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("enter number");
		int number = s.nextInt();

		int array[] = getMultiplesArray(number);
		for (int i = 0; i < array.length; i++) {

			System.out.println(array[i]);
		}
	}

}
