package Assignment_3;

import java.util.Scanner;

public class GenerateOddPalindrome {
	public String getOddPalindromeList(int firstValue, int secondValue) {

		if (firstValue <= 0 || secondValue <= 0) {
			return "Error";
		} else if ((firstValue < 100 && firstValue > 999) || (secondValue < 100 && secondValue > 999)) {
			return "Error";
		} else {
			String result = "";
			for (int i = firstValue; i <= secondValue; i++) {
				int reminder, sum = 0;
				int temp = i;
				while (temp != 0) {
					reminder = temp % 10;
					sum = sum * 10 + reminder;
					temp = temp / 10;
				}
				if (sum == i) {
					if (i % 2 != 0) {
						result += i + " ";
					}
				}
			}
			return result;
		}

	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("enter first number");
		int firstValue = s.nextInt();

		System.out.println("enter second number");
		int secondValue = s.nextInt();

		GenerateOddPalindrome gp = new GenerateOddPalindrome();
		System.out.println(gp.getOddPalindromeList(firstValue, secondValue));

	}

}
