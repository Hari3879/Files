package Assignment_3;

import java.util.Scanner;

public class GeneratePalindrome {
	public static String result = "";

	public static String getPalindromeList(int number) {

		result += number + ",";

		int reminder, sum = 0;
		int temp = number;
		while (temp != 0) {
			reminder = temp % 10;
			sum = sum * 10 + reminder;
			temp = temp / 10;
		}
		if (sum == number) {
			if (result.endsWith(",")) {
				result = result.substring(0, result.length() - 1);
			}
		} else {
			result += sum + ",";
			sum += number;
			int var = sum;
			getPalindromeList(var);
		}

		return result;
	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("enter number");
		int number = s.nextInt();

		System.out.println(getPalindromeList(number));
	}

}
