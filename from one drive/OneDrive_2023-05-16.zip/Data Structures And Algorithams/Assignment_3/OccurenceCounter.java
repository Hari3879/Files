package Assignment_3;

import java.util.Scanner;

public class OccurenceCounter {
	public int getCount(int array[], int number) {
		int count = 0;
		for (int i = 0; i < array.length; i++) {
			if (number == array[i]) {
				count++;
			}
		}
		return count;
	}

	public static void main(String[] args) {

		int array[] = { 1, 2, 3, 1, 1, 2 };

		Scanner s = new Scanner(System.in);
		System.out.println("enter number");
		int number = s.nextInt();

		OccurenceCounter oc = new OccurenceCounter();
		System.out.println(oc.getCount(array, number));

	}

}
