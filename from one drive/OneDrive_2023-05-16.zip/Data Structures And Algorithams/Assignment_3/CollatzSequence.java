package Assignment_3;

import java.util.Scanner;

public class CollatzSequence {
	public String getCollatzSequence(int num) {
		String result = num + " ";
		while (num != 1) {
			if (num % 2 == 0) {
				num /= 2;
				result += num + " ";

			} else {
				num = 3 * num + 1;
				result += num + " ";
			}
		}
		return result;

	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("enter number");
		int number = s.nextInt();

		CollatzSequence cs = new CollatzSequence();
		System.out.println(cs.getCollatzSequence(number));

	}

}
