package Assignment_3;

import java.util.HashSet;
import java.util.Set;

public class SumOfArray {
	public int sumOfArray(int array[]) {
		int sum = 0;
		Set<Integer> s = new HashSet<Integer>();
		if (array.length == 0) {
			return -1;
		} else {
			for (int i = 0; i < array.length; i++) {
				if (array[i] < 0) {
					return -2;
				} else
					s.add(array[i]);
			}
			for (int result : s) {
				sum += result;
			}
			return sum;

		}
	}

	public static void main(String[] args) {
		int array[] = {1, 2, 3, 2, 2, 5};

		SumOfArray sa = new SumOfArray();
		System.out.println(sa.sumOfArray(array));

	}

}
