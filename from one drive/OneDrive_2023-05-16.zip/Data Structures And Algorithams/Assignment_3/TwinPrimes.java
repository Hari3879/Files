package Assignment_3;

import java.util.Scanner;

public class TwinPrimes {
	public boolean isPrime(int number) {
		int count = 0;
		for (int i = 1; i <= number; i++) {
			if (number % i == 0) {
				count++;
			}
		}
		if (count <= 2) {
			return true;
		} else
			return false;
	}

	public String getTwinPrimes(int firstValue, int secondValue) {

		if (firstValue < 0 || secondValue < 0) {
			return "Error";
		} else if (firstValue > 100 || secondValue > 100) {
			return "Error";
		} else if (firstValue >= secondValue) {
			return "Error";
		} else {
			String result = "";
			for (int i = firstValue; i <= secondValue; i++) {
				if (i + 2 <= secondValue) {
					if (isPrime(i) && isPrime(i + 2)) {
						result += i + "," + (i + 2) + ";";
					}
				}
			}
			return result;
		}
	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("enter first value");
		int firstValue = s.nextInt();

		System.out.println("enter second value");
		int secondValue = s.nextInt();

		TwinPrimes tp = new TwinPrimes();
		if (tp.getTwinPrimes(firstValue, secondValue) == "") {
			System.out.println("twin numbers not found");
		} else
			System.out.println(tp.getTwinPrimes(firstValue, secondValue));

	}

}
