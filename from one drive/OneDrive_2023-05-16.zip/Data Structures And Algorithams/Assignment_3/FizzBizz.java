package Assignment_3;

import java.util.Scanner;

public class FizzBizz {
	public String getFizzBizz(int number) {
		if (number % 3 == 0 && number % 5 == 0) {
			return "FIZZBIZZ";
		} else if (number % 5 == 0) {
			return "BIZZ";
		} else if (number % 3 == 0) {
			return "FIZZ";
		} else
			return number + "";
	}

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("enter number");
		int number = s.nextInt();

		FizzBizz fb = new FizzBizz();
		System.out.println(fb.getFizzBizz(number));

	}

}
