package Assignment_3;

import java.util.Scanner;

public class Adder {
public String getSum(int firstNumber,int secondNumber){
	
	if(firstNumber<=0||secondNumber<=0){
		return "Error";
	}
	else
		return firstNumber+secondNumber+" ";
	
}
	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("enter first number");
		int firstNumber=s.nextInt();
		
		System.out.println("enter second number");
		int secondNumber=s.nextInt();
		
		Adder a=new Adder();
		System.out.println("Addition of 2 numbers is:"+a.getSum(firstNumber, secondNumber));

	}

}
